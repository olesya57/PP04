﻿namespace Learning___Program
{
    partial class PascalLesson1Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlQuestions = new System.Windows.Forms.TabControl();
            this.theoryTab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.theoryLabel4 = new System.Windows.Forms.Label();
            this.exampleCodeTextBox2 = new System.Windows.Forms.TextBox();
            this.exampleCodeTextBox = new System.Windows.Forms.TextBox();
            this.theoryLabel2 = new System.Windows.Forms.Label();
            this.theoryLabel1 = new System.Windows.Forms.Label();
            this.questionsTab = new System.Windows.Forms.TabPage();
            this.question3GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion3Button = new System.Windows.Forms.Button();
            this.answer3RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question2GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion2Button = new System.Windows.Forms.Button();
            this.answer2RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question1GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion1Button = new System.Windows.Forms.Button();
            this.answer1RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton1 = new System.Windows.Forms.RadioButton();
            this.practiceTab = new System.Windows.Forms.TabPage();
            this.checkTask2Button = new System.Windows.Forms.Button();
            this.task2CodeBox = new System.Windows.Forms.TextBox();
            this.task2Label = new System.Windows.Forms.Label();
            this.checkPracticeButton = new System.Windows.Forms.Button();
            this.practiceCodeTextBox = new System.Windows.Forms.TextBox();
            this.practiceTaskLabel = new System.Windows.Forms.Label();
            this.advancedTab = new System.Windows.Forms.TabPage();
            this.finishButton = new System.Windows.Forms.Button();
            this.checkAdvancedButton = new System.Windows.Forms.Button();
            this.advancedCodeTextBox = new System.Windows.Forms.TextBox();
            this.advancedTaskLabel = new System.Windows.Forms.Label();
            this.tabControlQuestions.SuspendLayout();
            this.theoryTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.questionsTab.SuspendLayout();
            this.question3GroupBox.SuspendLayout();
            this.question2GroupBox.SuspendLayout();
            this.question1GroupBox.SuspendLayout();
            this.practiceTab.SuspendLayout();
            this.advancedTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlQuestions
            // 
            this.tabControlQuestions.Controls.Add(this.theoryTab);
            this.tabControlQuestions.Controls.Add(this.questionsTab);
            this.tabControlQuestions.Controls.Add(this.practiceTab);
            this.tabControlQuestions.Controls.Add(this.advancedTab);
            this.tabControlQuestions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlQuestions.Location = new System.Drawing.Point(0, 0);
            this.tabControlQuestions.Name = "tabControlQuestions";
            this.tabControlQuestions.SelectedIndex = 0;
            this.tabControlQuestions.Size = new System.Drawing.Size(900, 630);
            this.tabControlQuestions.TabIndex = 33;
            // 
            // theoryTab
            // 
            this.theoryTab.Controls.Add(this.panel1);
            this.theoryTab.Location = new System.Drawing.Point(4, 25);
            this.theoryTab.Name = "theoryTab";
            this.theoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.theoryTab.Size = new System.Drawing.Size(892, 601);
            this.theoryTab.TabIndex = 0;
            this.theoryTab.Text = "Теория";
            this.theoryTab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Thistle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.theoryLabel4);
            this.panel1.Controls.Add(this.exampleCodeTextBox2);
            this.panel1.Controls.Add(this.exampleCodeTextBox);
            this.panel1.Controls.Add(this.theoryLabel2);
            this.panel1.Controls.Add(this.theoryLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 595);
            this.panel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(24, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Пример:";
            // 
            // theoryLabel4
            // 
            this.theoryLabel4.AutoSize = true;
            this.theoryLabel4.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theoryLabel4.Location = new System.Drawing.Point(28, 282);
            this.theoryLabel4.Name = "theoryLabel4";
            this.theoryLabel4.Size = new System.Drawing.Size(631, 20);
            this.theoryLabel4.TabIndex = 8;
            this.theoryLabel4.Text = "Команда вывода: writeln(\'Текст\'); — выводит текст на экран и переходит на новую с" +
    "троку.\r\n";
            // 
            // exampleCodeTextBox2
            // 
            this.exampleCodeTextBox2.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exampleCodeTextBox2.Location = new System.Drawing.Point(28, 332);
            this.exampleCodeTextBox2.Multiline = true;
            this.exampleCodeTextBox2.Name = "exampleCodeTextBox2";
            this.exampleCodeTextBox2.ReadOnly = true;
            this.exampleCodeTextBox2.Size = new System.Drawing.Size(771, 107);
            this.exampleCodeTextBox2.TabIndex = 4;
            this.exampleCodeTextBox2.Text = "program HelloWorld;\r\nbegin\r\n  writeln(\'Привет, мир!\');\r\n  writeln(\'Я учу Pascal!\'" +
    ");\r\nend.";
            // 
            // exampleCodeTextBox
            // 
            this.exampleCodeTextBox.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exampleCodeTextBox.Location = new System.Drawing.Point(28, 128);
            this.exampleCodeTextBox.Multiline = true;
            this.exampleCodeTextBox.Name = "exampleCodeTextBox";
            this.exampleCodeTextBox.ReadOnly = true;
            this.exampleCodeTextBox.Size = new System.Drawing.Size(771, 99);
            this.exampleCodeTextBox.TabIndex = 2;
            this.exampleCodeTextBox.Text = "program НазваниеПрограммы;  // Заголовок программы\r\nbegin                       /" +
    "/ Начало программы\r\n  // Здесь пишем команды\r\nend.                        // Кон" +
    "ец программы\r\n";
            // 
            // theoryLabel2
            // 
            this.theoryLabel2.AutoSize = true;
            this.theoryLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theoryLabel2.Location = new System.Drawing.Point(28, 93);
            this.theoryLabel2.Name = "theoryLabel2";
            this.theoryLabel2.Size = new System.Drawing.Size(167, 20);
            this.theoryLabel2.TabIndex = 1;
            this.theoryLabel2.Text = "Структура программы:";
            // 
            // theoryLabel1
            // 
            this.theoryLabel1.AutoSize = true;
            this.theoryLabel1.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theoryLabel1.Location = new System.Drawing.Point(28, 36);
            this.theoryLabel1.Name = "theoryLabel1";
            this.theoryLabel1.Size = new System.Drawing.Size(723, 20);
            this.theoryLabel1.TabIndex = 0;
            this.theoryLabel1.Text = "Pascal — это язык программирования, созданный для обучения структурному программи" +
    "рованию.";
            // 
            // questionsTab
            // 
            this.questionsTab.BackColor = System.Drawing.Color.Thistle;
            this.questionsTab.Controls.Add(this.question3GroupBox);
            this.questionsTab.Controls.Add(this.question2GroupBox);
            this.questionsTab.Controls.Add(this.question1GroupBox);
            this.questionsTab.Location = new System.Drawing.Point(4, 25);
            this.questionsTab.Name = "questionsTab";
            this.questionsTab.Padding = new System.Windows.Forms.Padding(3);
            this.questionsTab.Size = new System.Drawing.Size(892, 601);
            this.questionsTab.TabIndex = 1;
            this.questionsTab.Text = "Вопросы";
            // 
            // question3GroupBox
            // 
            this.question3GroupBox.Controls.Add(this.checkQuestion3Button);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton4);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton3);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton2);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton1);
            this.question3GroupBox.Location = new System.Drawing.Point(8, 348);
            this.question3GroupBox.Name = "question3GroupBox";
            this.question3GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question3GroupBox.TabIndex = 5;
            this.question3GroupBox.TabStop = false;
            this.question3GroupBox.Text = "3";
            // 
            // checkQuestion3Button
            // 
            this.checkQuestion3Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion3Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion3Button.Name = "checkQuestion3Button";
            this.checkQuestion3Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion3Button.TabIndex = 5;
            this.checkQuestion3Button.Text = "Ответить";
            this.checkQuestion3Button.UseVisualStyleBackColor = false;
            // 
            // answer3RadioButton4
            // 
            this.answer3RadioButton4.AutoSize = true;
            this.answer3RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer3RadioButton4.Name = "answer3RadioButton4";
            this.answer3RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton4.TabIndex = 3;
            this.answer3RadioButton4.TabStop = true;
            this.answer3RadioButton4.Text = "radioButton1";
            this.answer3RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton3
            // 
            this.answer3RadioButton3.AutoSize = true;
            this.answer3RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer3RadioButton3.Name = "answer3RadioButton3";
            this.answer3RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton3.TabIndex = 2;
            this.answer3RadioButton3.TabStop = true;
            this.answer3RadioButton3.Text = "radioButton1";
            this.answer3RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton2
            // 
            this.answer3RadioButton2.AutoSize = true;
            this.answer3RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer3RadioButton2.Name = "answer3RadioButton2";
            this.answer3RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton2.TabIndex = 1;
            this.answer3RadioButton2.TabStop = true;
            this.answer3RadioButton2.Text = "radioButton1";
            this.answer3RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton1
            // 
            this.answer3RadioButton1.AutoSize = true;
            this.answer3RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer3RadioButton1.Name = "answer3RadioButton1";
            this.answer3RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton1.TabIndex = 0;
            this.answer3RadioButton1.TabStop = true;
            this.answer3RadioButton1.Text = "radioButton1";
            this.answer3RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question2GroupBox
            // 
            this.question2GroupBox.Controls.Add(this.checkQuestion2Button);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton4);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton3);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton2);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton1);
            this.question2GroupBox.Location = new System.Drawing.Point(8, 203);
            this.question2GroupBox.Name = "question2GroupBox";
            this.question2GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question2GroupBox.TabIndex = 4;
            this.question2GroupBox.TabStop = false;
            this.question2GroupBox.Text = "groupBox1";
            // 
            // checkQuestion2Button
            // 
            this.checkQuestion2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion2Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion2Button.Name = "checkQuestion2Button";
            this.checkQuestion2Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion2Button.TabIndex = 5;
            this.checkQuestion2Button.Text = "Ответить";
            this.checkQuestion2Button.UseVisualStyleBackColor = false;
            // 
            // answer2RadioButton4
            // 
            this.answer2RadioButton4.AutoSize = true;
            this.answer2RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer2RadioButton4.Name = "answer2RadioButton4";
            this.answer2RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton4.TabIndex = 3;
            this.answer2RadioButton4.TabStop = true;
            this.answer2RadioButton4.Text = "radioButton1";
            this.answer2RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton3
            // 
            this.answer2RadioButton3.AutoSize = true;
            this.answer2RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer2RadioButton3.Name = "answer2RadioButton3";
            this.answer2RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton3.TabIndex = 2;
            this.answer2RadioButton3.TabStop = true;
            this.answer2RadioButton3.Text = "radioButton1";
            this.answer2RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton2
            // 
            this.answer2RadioButton2.AutoSize = true;
            this.answer2RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer2RadioButton2.Name = "answer2RadioButton2";
            this.answer2RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton2.TabIndex = 1;
            this.answer2RadioButton2.TabStop = true;
            this.answer2RadioButton2.Text = "radioButton1";
            this.answer2RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton1
            // 
            this.answer2RadioButton1.AutoSize = true;
            this.answer2RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer2RadioButton1.Name = "answer2RadioButton1";
            this.answer2RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton1.TabIndex = 0;
            this.answer2RadioButton1.TabStop = true;
            this.answer2RadioButton1.Text = "radioButton1";
            this.answer2RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question1GroupBox
            // 
            this.question1GroupBox.Controls.Add(this.checkQuestion1Button);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton4);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton3);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton2);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton1);
            this.question1GroupBox.Location = new System.Drawing.Point(8, 58);
            this.question1GroupBox.Name = "question1GroupBox";
            this.question1GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question1GroupBox.TabIndex = 0;
            this.question1GroupBox.TabStop = false;
            this.question1GroupBox.Text = "groupBox1";
            // 
            // checkQuestion1Button
            // 
            this.checkQuestion1Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion1Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion1Button.Name = "checkQuestion1Button";
            this.checkQuestion1Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion1Button.TabIndex = 4;
            this.checkQuestion1Button.Text = "Ответить";
            this.checkQuestion1Button.UseVisualStyleBackColor = false;
            // 
            // answer1RadioButton4
            // 
            this.answer1RadioButton4.AutoSize = true;
            this.answer1RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer1RadioButton4.Name = "answer1RadioButton4";
            this.answer1RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton4.TabIndex = 3;
            this.answer1RadioButton4.TabStop = true;
            this.answer1RadioButton4.Text = "radioButton1";
            this.answer1RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton3
            // 
            this.answer1RadioButton3.AutoSize = true;
            this.answer1RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer1RadioButton3.Name = "answer1RadioButton3";
            this.answer1RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton3.TabIndex = 2;
            this.answer1RadioButton3.TabStop = true;
            this.answer1RadioButton3.Text = "radioButton1";
            this.answer1RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton2
            // 
            this.answer1RadioButton2.AutoSize = true;
            this.answer1RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer1RadioButton2.Name = "answer1RadioButton2";
            this.answer1RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton2.TabIndex = 1;
            this.answer1RadioButton2.TabStop = true;
            this.answer1RadioButton2.Text = "radioButton1";
            this.answer1RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton1
            // 
            this.answer1RadioButton1.AutoSize = true;
            this.answer1RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer1RadioButton1.Name = "answer1RadioButton1";
            this.answer1RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton1.TabIndex = 0;
            this.answer1RadioButton1.TabStop = true;
            this.answer1RadioButton1.Text = "radioButton1";
            this.answer1RadioButton1.UseVisualStyleBackColor = true;
            // 
            // practiceTab
            // 
            this.practiceTab.BackColor = System.Drawing.Color.Thistle;
            this.practiceTab.Controls.Add(this.checkTask2Button);
            this.practiceTab.Controls.Add(this.task2CodeBox);
            this.practiceTab.Controls.Add(this.task2Label);
            this.practiceTab.Controls.Add(this.checkPracticeButton);
            this.practiceTab.Controls.Add(this.practiceCodeTextBox);
            this.practiceTab.Controls.Add(this.practiceTaskLabel);
            this.practiceTab.Location = new System.Drawing.Point(4, 25);
            this.practiceTab.Name = "practiceTab";
            this.practiceTab.Size = new System.Drawing.Size(892, 601);
            this.practiceTab.TabIndex = 2;
            this.practiceTab.Text = "Задания";
            // 
            // checkTask2Button
            // 
            this.checkTask2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask2Button.Location = new System.Drawing.Point(34, 545);
            this.checkTask2Button.Name = "checkTask2Button";
            this.checkTask2Button.Size = new System.Drawing.Size(110, 41);
            this.checkTask2Button.TabIndex = 6;
            this.checkTask2Button.Text = "Проверить";
            this.checkTask2Button.UseVisualStyleBackColor = false;
            // 
            // task2CodeBox
            // 
            this.task2CodeBox.Location = new System.Drawing.Point(34, 423);
            this.task2CodeBox.Multiline = true;
            this.task2CodeBox.Name = "task2CodeBox";
            this.task2CodeBox.Size = new System.Drawing.Size(517, 116);
            this.task2CodeBox.TabIndex = 5;
            // 
            // task2Label
            // 
            this.task2Label.AutoSize = true;
            this.task2Label.Location = new System.Drawing.Point(31, 314);
            this.task2Label.Name = "task2Label";
            this.task2Label.Size = new System.Drawing.Size(44, 16);
            this.task2Label.TabIndex = 4;
            this.task2Label.Text = "label1";
            // 
            // checkPracticeButton
            // 
            this.checkPracticeButton.BackColor = System.Drawing.Color.LightYellow;
            this.checkPracticeButton.Location = new System.Drawing.Point(34, 242);
            this.checkPracticeButton.Name = "checkPracticeButton";
            this.checkPracticeButton.Size = new System.Drawing.Size(110, 41);
            this.checkPracticeButton.TabIndex = 2;
            this.checkPracticeButton.Text = "Проверить";
            this.checkPracticeButton.UseVisualStyleBackColor = false;
            // 
            // practiceCodeTextBox
            // 
            this.practiceCodeTextBox.Location = new System.Drawing.Point(34, 120);
            this.practiceCodeTextBox.Multiline = true;
            this.practiceCodeTextBox.Name = "practiceCodeTextBox";
            this.practiceCodeTextBox.Size = new System.Drawing.Size(517, 116);
            this.practiceCodeTextBox.TabIndex = 1;
            // 
            // practiceTaskLabel
            // 
            this.practiceTaskLabel.AutoSize = true;
            this.practiceTaskLabel.Location = new System.Drawing.Point(31, 13);
            this.practiceTaskLabel.Name = "practiceTaskLabel";
            this.practiceTaskLabel.Size = new System.Drawing.Size(44, 16);
            this.practiceTaskLabel.TabIndex = 0;
            this.practiceTaskLabel.Text = "label1";
            // 
            // advancedTab
            // 
            this.advancedTab.BackColor = System.Drawing.Color.Thistle;
            this.advancedTab.Controls.Add(this.finishButton);
            this.advancedTab.Controls.Add(this.checkAdvancedButton);
            this.advancedTab.Controls.Add(this.advancedCodeTextBox);
            this.advancedTab.Controls.Add(this.advancedTaskLabel);
            this.advancedTab.Location = new System.Drawing.Point(4, 25);
            this.advancedTab.Name = "advancedTab";
            this.advancedTab.Size = new System.Drawing.Size(892, 601);
            this.advancedTab.TabIndex = 3;
            this.advancedTab.Text = "Доп. задание";
            // 
            // finishButton
            // 
            this.finishButton.BackColor = System.Drawing.Color.LightYellow;
            this.finishButton.Location = new System.Drawing.Point(723, 529);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(149, 54);
            this.finishButton.TabIndex = 0;
            this.finishButton.Text = "Завершить";
            this.finishButton.UseVisualStyleBackColor = false;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // checkAdvancedButton
            // 
            this.checkAdvancedButton.BackColor = System.Drawing.Color.LightYellow;
            this.checkAdvancedButton.Location = new System.Drawing.Point(36, 538);
            this.checkAdvancedButton.Name = "checkAdvancedButton";
            this.checkAdvancedButton.Size = new System.Drawing.Size(99, 37);
            this.checkAdvancedButton.TabIndex = 5;
            this.checkAdvancedButton.Text = "Проверить";
            this.checkAdvancedButton.UseVisualStyleBackColor = false;
            // 
            // advancedCodeTextBox
            // 
            this.advancedCodeTextBox.Location = new System.Drawing.Point(36, 183);
            this.advancedCodeTextBox.Multiline = true;
            this.advancedCodeTextBox.Name = "advancedCodeTextBox";
            this.advancedCodeTextBox.Size = new System.Drawing.Size(436, 349);
            this.advancedCodeTextBox.TabIndex = 4;
            // 
            // advancedTaskLabel
            // 
            this.advancedTaskLabel.AutoSize = true;
            this.advancedTaskLabel.Location = new System.Drawing.Point(33, 24);
            this.advancedTaskLabel.Name = "advancedTaskLabel";
            this.advancedTaskLabel.Size = new System.Drawing.Size(44, 16);
            this.advancedTaskLabel.TabIndex = 3;
            this.advancedTaskLabel.Text = "label1";
            // 
            // PascalLesson1Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(900, 630);
            this.Controls.Add(this.tabControlQuestions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "PascalLesson1Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Урок 1: Знакомство с Pascal. Структура программы";
            this.tabControlQuestions.ResumeLayout(false);
            this.theoryTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.questionsTab.ResumeLayout(false);
            this.question3GroupBox.ResumeLayout(false);
            this.question3GroupBox.PerformLayout();
            this.question2GroupBox.ResumeLayout(false);
            this.question2GroupBox.PerformLayout();
            this.question1GroupBox.ResumeLayout(false);
            this.question1GroupBox.PerformLayout();
            this.practiceTab.ResumeLayout(false);
            this.practiceTab.PerformLayout();
            this.advancedTab.ResumeLayout(false);
            this.advancedTab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlQuestions;
        private System.Windows.Forms.TabPage theoryTab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label theoryLabel4;
        private System.Windows.Forms.TextBox exampleCodeTextBox2;
        private System.Windows.Forms.TextBox exampleCodeTextBox;
        private System.Windows.Forms.Label theoryLabel2;
        private System.Windows.Forms.Label theoryLabel1;
        private System.Windows.Forms.TabPage questionsTab;
        private System.Windows.Forms.GroupBox question3GroupBox;
        private System.Windows.Forms.Button checkQuestion3Button;
        private System.Windows.Forms.RadioButton answer3RadioButton4;
        private System.Windows.Forms.RadioButton answer3RadioButton3;
        private System.Windows.Forms.RadioButton answer3RadioButton2;
        private System.Windows.Forms.RadioButton answer3RadioButton1;
        private System.Windows.Forms.GroupBox question2GroupBox;
        private System.Windows.Forms.Button checkQuestion2Button;
        private System.Windows.Forms.RadioButton answer2RadioButton4;
        private System.Windows.Forms.RadioButton answer2RadioButton3;
        private System.Windows.Forms.RadioButton answer2RadioButton2;
        private System.Windows.Forms.RadioButton answer2RadioButton1;
        private System.Windows.Forms.GroupBox question1GroupBox;
        private System.Windows.Forms.Button checkQuestion1Button;
        private System.Windows.Forms.RadioButton answer1RadioButton4;
        private System.Windows.Forms.RadioButton answer1RadioButton3;
        private System.Windows.Forms.RadioButton answer1RadioButton2;
        private System.Windows.Forms.RadioButton answer1RadioButton1;
        private System.Windows.Forms.TabPage practiceTab;
        private System.Windows.Forms.Button checkTask2Button;
        private System.Windows.Forms.TextBox task2CodeBox;
        private System.Windows.Forms.Label task2Label;
        private System.Windows.Forms.Button checkPracticeButton;
        private System.Windows.Forms.TextBox practiceCodeTextBox;
        private System.Windows.Forms.Label practiceTaskLabel;
        private System.Windows.Forms.TabPage advancedTab;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.Button checkAdvancedButton;
        private System.Windows.Forms.TextBox advancedCodeTextBox;
        private System.Windows.Forms.Label advancedTaskLabel;
    }
}