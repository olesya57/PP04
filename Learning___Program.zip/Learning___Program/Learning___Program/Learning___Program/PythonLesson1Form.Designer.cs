﻿namespace Learning___Program
{
    partial class PythonLesson1Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PythonLesson1Form));
            this.tabControlQuestions = new System.Windows.Forms.TabControl();
            this.theoryTab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.theoryLabel4 = new System.Windows.Forms.Label();
            this.theoryLabel3 = new System.Windows.Forms.Label();
            this.exampleCodeTextBox3 = new System.Windows.Forms.TextBox();
            this.theoryLabel5 = new System.Windows.Forms.Label();
            this.exampleCodeTextBox2 = new System.Windows.Forms.TextBox();
            this.exampleCodeTextBox = new System.Windows.Forms.TextBox();
            this.theoryLabel2 = new System.Windows.Forms.Label();
            this.theoryLabel1 = new System.Windows.Forms.Label();
            this.questionsTab = new System.Windows.Forms.TabPage();
            this.question4GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion4Button = new System.Windows.Forms.Button();
            this.answer4RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question3GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion3Button = new System.Windows.Forms.Button();
            this.answer3RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question2GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion2Button = new System.Windows.Forms.Button();
            this.answer2RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question1GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion1Button = new System.Windows.Forms.Button();
            this.answer1RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton1 = new System.Windows.Forms.RadioButton();
            this.practiceTab = new System.Windows.Forms.TabPage();
            this.checkTask3Button = new System.Windows.Forms.Button();
            this.task3ExplanationBox = new System.Windows.Forms.TextBox();
            this.task3Label = new System.Windows.Forms.Label();
            this.checkTask2Button = new System.Windows.Forms.Button();
            this.task2CodeBox = new System.Windows.Forms.TextBox();
            this.task2Label = new System.Windows.Forms.Label();
            this.checkPracticeButton = new System.Windows.Forms.Button();
            this.practiceCodeTextBox = new System.Windows.Forms.TextBox();
            this.practiceTaskLabel = new System.Windows.Forms.Label();
            this.advancedTab = new System.Windows.Forms.TabPage();
            this.finishButton = new System.Windows.Forms.Button();
            this.checkTask2Button1 = new System.Windows.Forms.Button();
            this.advancedCodeTextBox2 = new System.Windows.Forms.TextBox();
            this.advancedTask2Group = new System.Windows.Forms.Label();
            this.checkTask1Button = new System.Windows.Forms.Button();
            this.advancedCodeTextBox1 = new System.Windows.Forms.TextBox();
            this.advancedTask1Group = new System.Windows.Forms.Label();
            this.tabControlQuestions.SuspendLayout();
            this.theoryTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.questionsTab.SuspendLayout();
            this.question4GroupBox.SuspendLayout();
            this.question3GroupBox.SuspendLayout();
            this.question2GroupBox.SuspendLayout();
            this.question1GroupBox.SuspendLayout();
            this.practiceTab.SuspendLayout();
            this.advancedTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlQuestions
            // 
            this.tabControlQuestions.Controls.Add(this.theoryTab);
            this.tabControlQuestions.Controls.Add(this.questionsTab);
            this.tabControlQuestions.Controls.Add(this.practiceTab);
            this.tabControlQuestions.Controls.Add(this.advancedTab);
            this.tabControlQuestions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlQuestions.Location = new System.Drawing.Point(0, 0);
            this.tabControlQuestions.Name = "tabControlQuestions";
            this.tabControlQuestions.SelectedIndex = 0;
            this.tabControlQuestions.Size = new System.Drawing.Size(1171, 714);
            this.tabControlQuestions.TabIndex = 32;
            // 
            // theoryTab
            // 
            this.theoryTab.Controls.Add(this.panel1);
            this.theoryTab.Location = new System.Drawing.Point(4, 25);
            this.theoryTab.Name = "theoryTab";
            this.theoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.theoryTab.Size = new System.Drawing.Size(1163, 685);
            this.theoryTab.TabIndex = 0;
            this.theoryTab.Text = "Теория";
            this.theoryTab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Thistle;
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.theoryLabel4);
            this.panel1.Controls.Add(this.theoryLabel3);
            this.panel1.Controls.Add(this.exampleCodeTextBox3);
            this.panel1.Controls.Add(this.theoryLabel5);
            this.panel1.Controls.Add(this.exampleCodeTextBox2);
            this.panel1.Controls.Add(this.exampleCodeTextBox);
            this.panel1.Controls.Add(this.theoryLabel2);
            this.panel1.Controls.Add(this.theoryLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1157, 679);
            this.panel1.TabIndex = 19;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(14, 570);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(510, 104);
            this.textBox4.TabIndex = 24;
            this.textBox4.Text = "num = int(input(\"Введите число: \"))\r\n\r\nif num % 2 == 0: # через чётное (через неч" +
    "ётное \"if num % 2 != 0:\")\r\n    print(f\"Число {num} чётное\")\r\nelse:\r\n    print(f\"" +
    "Число {num} нечётное\")";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label9.Location = new System.Drawing.Point(14, 518);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(467, 40);
            this.label9.TabIndex = 23;
            this.label9.Text = "Примечание:\r\nЕсли вам нужно проверить, является ли число чётным/нечётным";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(609, 210);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(306, 83);
            this.textBox2.TabIndex = 22;
            this.textBox2.Text = "length = 5\r\nwidth = 3\r\narea = length * width  # Умножение\r\nprint(\"Площадь:\", area" +
    ")  # Вывод: 15";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label5.Location = new System.Drawing.Point(605, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "Пример:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label8.Location = new System.Drawing.Point(605, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(443, 100);
            this.label8.TabIndex = 20;
            this.label8.Text = resources.GetString("label8.Text");
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label7.Location = new System.Drawing.Point(608, 589);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(266, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "Пример с несколькими значениями:\r\n";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(609, 612);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(528, 37);
            this.textBox3.TabIndex = 15;
            this.textBox3.Text = "print(\"Имя:\", name, \"Возраст:\", age)  # Вывод: Имя: Капп Возраст: 25  \r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label6.Location = new System.Drawing.Point(608, 509);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(453, 80);
            this.label6.TabIndex = 14;
            this.label6.Text = "Примечание:\r\nМожно выводить несколько значений, разделяя их запятыми.\r\nПо умолчан" +
    "ию print() добавляет пробел между аргументами и \r\nперенос строки в конце.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label3.Location = new System.Drawing.Point(608, 403);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Пример";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(606, 426);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(528, 80);
            this.textBox1.TabIndex = 12;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label4.Location = new System.Drawing.Point(605, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(489, 80);
            this.label4.TabIndex = 11;
            this.label4.Text = "5. Функция print()\r\nФункция print() используется для вывода информации на экран. " +
    "\r\nОна может выводить значения переменных, строки, числа и другие \r\nтипы данных.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label2.Location = new System.Drawing.Point(14, 412);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Пример";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label1.Location = new System.Drawing.Point(14, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Пример";
            // 
            // theoryLabel4
            // 
            this.theoryLabel4.AutoSize = true;
            this.theoryLabel4.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel4.Location = new System.Drawing.Point(10, 195);
            this.theoryLabel4.Name = "theoryLabel4";
            this.theoryLabel4.Size = new System.Drawing.Size(455, 60);
            this.theoryLabel4.TabIndex = 8;
            this.theoryLabel4.Text = "2. Как создаются переменные?\r\n- Имя переменной должно быть одним словом (без проб" +
    "елов)\r\n- После имени ставится знак =, а затем - значение";
            // 
            // theoryLabel3
            // 
            this.theoryLabel3.AutoSize = true;
            this.theoryLabel3.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel3.Location = new System.Drawing.Point(10, 133);
            this.theoryLabel3.Name = "theoryLabel3";
            this.theoryLabel3.Size = new System.Drawing.Size(66, 20);
            this.theoryLabel3.TabIndex = 7;
            this.theoryLabel3.Text = "Пример";
            // 
            // exampleCodeTextBox3
            // 
            this.exampleCodeTextBox3.Location = new System.Drawing.Point(14, 435);
            this.exampleCodeTextBox3.Multiline = true;
            this.exampleCodeTextBox3.Name = "exampleCodeTextBox3";
            this.exampleCodeTextBox3.ReadOnly = true;
            this.exampleCodeTextBox3.Size = new System.Drawing.Size(510, 80);
            this.exampleCodeTextBox3.TabIndex = 6;
            this.exampleCodeTextBox3.Text = resources.GetString("exampleCodeTextBox3.Text");
            // 
            // theoryLabel5
            // 
            this.theoryLabel5.AutoSize = true;
            this.theoryLabel5.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel5.Location = new System.Drawing.Point(14, 325);
            this.theoryLabel5.Name = "theoryLabel5";
            this.theoryLabel5.Size = new System.Drawing.Size(444, 80);
            this.theoryLabel5.TabIndex = 5;
            this.theoryLabel5.Text = "3. Для чего нужны переменные?\r\n- Чтобы хранить данные для повторного использовани" +
    "я\r\n- Чтобы упрощать код (например, использовать score вместо \r\nчисла 100 много р" +
    "аз)";
            // 
            // exampleCodeTextBox2
            // 
            this.exampleCodeTextBox2.Location = new System.Drawing.Point(14, 288);
            this.exampleCodeTextBox2.Multiline = true;
            this.exampleCodeTextBox2.Name = "exampleCodeTextBox2";
            this.exampleCodeTextBox2.ReadOnly = true;
            this.exampleCodeTextBox2.Size = new System.Drawing.Size(510, 27);
            this.exampleCodeTextBox2.TabIndex = 4;
            this.exampleCodeTextBox2.Text = " city = \"Miami\" # Создаём переменную \'city\' со значением \"Miami\"\r\n ";
            // 
            // exampleCodeTextBox
            // 
            this.exampleCodeTextBox.Location = new System.Drawing.Point(10, 156);
            this.exampleCodeTextBox.Multiline = true;
            this.exampleCodeTextBox.Name = "exampleCodeTextBox";
            this.exampleCodeTextBox.ReadOnly = true;
            this.exampleCodeTextBox.Size = new System.Drawing.Size(510, 34);
            this.exampleCodeTextBox.TabIndex = 2;
            this.exampleCodeTextBox.Text = "name = \"Karin\"  # Переменная \"name\" хранит строку \"Karin\"";
            // 
            // theoryLabel2
            // 
            this.theoryLabel2.AutoSize = true;
            this.theoryLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel2.Location = new System.Drawing.Point(14, 75);
            this.theoryLabel2.Name = "theoryLabel2";
            this.theoryLabel2.Size = new System.Drawing.Size(543, 60);
            this.theoryLabel2.TabIndex = 1;
            this.theoryLabel2.Text = "1. Что такое переменная?\r\nПеременная - это именованная область памяти, которая хр" +
    "анит данные. \r\nЕё можно представить как коробку с названием, в которой лежит зна" +
    "чение.";
            // 
            // theoryLabel1
            // 
            this.theoryLabel1.AutoSize = true;
            this.theoryLabel1.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theoryLabel1.Location = new System.Drawing.Point(14, 15);
            this.theoryLabel1.Name = "theoryLabel1";
            this.theoryLabel1.Size = new System.Drawing.Size(1081, 60);
            this.theoryLabel1.TabIndex = 0;
            this.theoryLabel1.Text = resources.GetString("theoryLabel1.Text");
            // 
            // questionsTab
            // 
            this.questionsTab.BackColor = System.Drawing.Color.Thistle;
            this.questionsTab.Controls.Add(this.question4GroupBox);
            this.questionsTab.Controls.Add(this.question3GroupBox);
            this.questionsTab.Controls.Add(this.question2GroupBox);
            this.questionsTab.Controls.Add(this.question1GroupBox);
            this.questionsTab.Location = new System.Drawing.Point(4, 25);
            this.questionsTab.Name = "questionsTab";
            this.questionsTab.Padding = new System.Windows.Forms.Padding(3);
            this.questionsTab.Size = new System.Drawing.Size(1163, 685);
            this.questionsTab.TabIndex = 1;
            this.questionsTab.Text = "Вопросы";
            // 
            // question4GroupBox
            // 
            this.question4GroupBox.Controls.Add(this.checkQuestion4Button);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton4);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton3);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton2);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton1);
            this.question4GroupBox.Location = new System.Drawing.Point(20, 455);
            this.question4GroupBox.Name = "question4GroupBox";
            this.question4GroupBox.Size = new System.Drawing.Size(1132, 161);
            this.question4GroupBox.TabIndex = 6;
            this.question4GroupBox.TabStop = false;
            this.question4GroupBox.Text = "groupBox1";
            // 
            // checkQuestion4Button
            // 
            this.checkQuestion4Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion4Button.Location = new System.Drawing.Point(973, 87);
            this.checkQuestion4Button.Name = "checkQuestion4Button";
            this.checkQuestion4Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion4Button.TabIndex = 5;
            this.checkQuestion4Button.Text = "Ответить";
            this.checkQuestion4Button.UseVisualStyleBackColor = false;
            // 
            // answer4RadioButton4
            // 
            this.answer4RadioButton4.AutoSize = true;
            this.answer4RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer4RadioButton4.Name = "answer4RadioButton4";
            this.answer4RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton4.TabIndex = 3;
            this.answer4RadioButton4.TabStop = true;
            this.answer4RadioButton4.Text = "radioButton1";
            this.answer4RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton3
            // 
            this.answer4RadioButton3.AutoSize = true;
            this.answer4RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer4RadioButton3.Name = "answer4RadioButton3";
            this.answer4RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton3.TabIndex = 2;
            this.answer4RadioButton3.TabStop = true;
            this.answer4RadioButton3.Text = "radioButton1";
            this.answer4RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton2
            // 
            this.answer4RadioButton2.AutoSize = true;
            this.answer4RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer4RadioButton2.Name = "answer4RadioButton2";
            this.answer4RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton2.TabIndex = 1;
            this.answer4RadioButton2.TabStop = true;
            this.answer4RadioButton2.Text = "radioButton1";
            this.answer4RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton1
            // 
            this.answer4RadioButton1.AutoSize = true;
            this.answer4RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer4RadioButton1.Name = "answer4RadioButton1";
            this.answer4RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton1.TabIndex = 0;
            this.answer4RadioButton1.TabStop = true;
            this.answer4RadioButton1.Text = "radioButton1";
            this.answer4RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question3GroupBox
            // 
            this.question3GroupBox.Controls.Add(this.checkQuestion3Button);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton4);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton3);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton2);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton1);
            this.question3GroupBox.Location = new System.Drawing.Point(20, 316);
            this.question3GroupBox.Name = "question3GroupBox";
            this.question3GroupBox.Size = new System.Drawing.Size(1126, 161);
            this.question3GroupBox.TabIndex = 5;
            this.question3GroupBox.TabStop = false;
            this.question3GroupBox.Text = "3";
            // 
            // checkQuestion3Button
            // 
            this.checkQuestion3Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion3Button.Location = new System.Drawing.Point(973, 74);
            this.checkQuestion3Button.Name = "checkQuestion3Button";
            this.checkQuestion3Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion3Button.TabIndex = 5;
            this.checkQuestion3Button.Text = "Ответить";
            this.checkQuestion3Button.UseVisualStyleBackColor = false;
            // 
            // answer3RadioButton4
            // 
            this.answer3RadioButton4.AutoSize = true;
            this.answer3RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer3RadioButton4.Name = "answer3RadioButton4";
            this.answer3RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton4.TabIndex = 3;
            this.answer3RadioButton4.TabStop = true;
            this.answer3RadioButton4.Text = "radioButton1";
            this.answer3RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton3
            // 
            this.answer3RadioButton3.AutoSize = true;
            this.answer3RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer3RadioButton3.Name = "answer3RadioButton3";
            this.answer3RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton3.TabIndex = 2;
            this.answer3RadioButton3.TabStop = true;
            this.answer3RadioButton3.Text = "radioButton1";
            this.answer3RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton2
            // 
            this.answer3RadioButton2.AutoSize = true;
            this.answer3RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer3RadioButton2.Name = "answer3RadioButton2";
            this.answer3RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton2.TabIndex = 1;
            this.answer3RadioButton2.TabStop = true;
            this.answer3RadioButton2.Text = "radioButton1";
            this.answer3RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton1
            // 
            this.answer3RadioButton1.AutoSize = true;
            this.answer3RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer3RadioButton1.Name = "answer3RadioButton1";
            this.answer3RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton1.TabIndex = 0;
            this.answer3RadioButton1.TabStop = true;
            this.answer3RadioButton1.Text = "radioButton1";
            this.answer3RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question2GroupBox
            // 
            this.question2GroupBox.Controls.Add(this.checkQuestion2Button);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton4);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton3);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton2);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton1);
            this.question2GroupBox.Location = new System.Drawing.Point(20, 171);
            this.question2GroupBox.Name = "question2GroupBox";
            this.question2GroupBox.Size = new System.Drawing.Size(1126, 161);
            this.question2GroupBox.TabIndex = 4;
            this.question2GroupBox.TabStop = false;
            this.question2GroupBox.Text = "groupBox1";
            // 
            // checkQuestion2Button
            // 
            this.checkQuestion2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion2Button.Location = new System.Drawing.Point(973, 87);
            this.checkQuestion2Button.Name = "checkQuestion2Button";
            this.checkQuestion2Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion2Button.TabIndex = 5;
            this.checkQuestion2Button.Text = "Ответить";
            this.checkQuestion2Button.UseVisualStyleBackColor = false;
            // 
            // answer2RadioButton4
            // 
            this.answer2RadioButton4.AutoSize = true;
            this.answer2RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer2RadioButton4.Name = "answer2RadioButton4";
            this.answer2RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton4.TabIndex = 3;
            this.answer2RadioButton4.TabStop = true;
            this.answer2RadioButton4.Text = "radioButton1";
            this.answer2RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton3
            // 
            this.answer2RadioButton3.AutoSize = true;
            this.answer2RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer2RadioButton3.Name = "answer2RadioButton3";
            this.answer2RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton3.TabIndex = 2;
            this.answer2RadioButton3.TabStop = true;
            this.answer2RadioButton3.Text = "radioButton1";
            this.answer2RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton2
            // 
            this.answer2RadioButton2.AutoSize = true;
            this.answer2RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer2RadioButton2.Name = "answer2RadioButton2";
            this.answer2RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton2.TabIndex = 1;
            this.answer2RadioButton2.TabStop = true;
            this.answer2RadioButton2.Text = "radioButton1";
            this.answer2RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton1
            // 
            this.answer2RadioButton1.AutoSize = true;
            this.answer2RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer2RadioButton1.Name = "answer2RadioButton1";
            this.answer2RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton1.TabIndex = 0;
            this.answer2RadioButton1.TabStop = true;
            this.answer2RadioButton1.Text = "radioButton1";
            this.answer2RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question1GroupBox
            // 
            this.question1GroupBox.Controls.Add(this.checkQuestion1Button);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton4);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton3);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton2);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton1);
            this.question1GroupBox.Location = new System.Drawing.Point(20, 26);
            this.question1GroupBox.Name = "question1GroupBox";
            this.question1GroupBox.Size = new System.Drawing.Size(1126, 161);
            this.question1GroupBox.TabIndex = 0;
            this.question1GroupBox.TabStop = false;
            this.question1GroupBox.Text = "groupBox1";
            // 
            // checkQuestion1Button
            // 
            this.checkQuestion1Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion1Button.Location = new System.Drawing.Point(973, 74);
            this.checkQuestion1Button.Name = "checkQuestion1Button";
            this.checkQuestion1Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion1Button.TabIndex = 4;
            this.checkQuestion1Button.Text = "Ответить";
            this.checkQuestion1Button.UseVisualStyleBackColor = false;
            // 
            // answer1RadioButton4
            // 
            this.answer1RadioButton4.AutoSize = true;
            this.answer1RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer1RadioButton4.Name = "answer1RadioButton4";
            this.answer1RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton4.TabIndex = 3;
            this.answer1RadioButton4.TabStop = true;
            this.answer1RadioButton4.Text = "radioButton1";
            this.answer1RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton3
            // 
            this.answer1RadioButton3.AutoSize = true;
            this.answer1RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer1RadioButton3.Name = "answer1RadioButton3";
            this.answer1RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton3.TabIndex = 2;
            this.answer1RadioButton3.TabStop = true;
            this.answer1RadioButton3.Text = "radioButton1";
            this.answer1RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton2
            // 
            this.answer1RadioButton2.AutoSize = true;
            this.answer1RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer1RadioButton2.Name = "answer1RadioButton2";
            this.answer1RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton2.TabIndex = 1;
            this.answer1RadioButton2.TabStop = true;
            this.answer1RadioButton2.Text = "radioButton1";
            this.answer1RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton1
            // 
            this.answer1RadioButton1.AutoSize = true;
            this.answer1RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer1RadioButton1.Name = "answer1RadioButton1";
            this.answer1RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton1.TabIndex = 0;
            this.answer1RadioButton1.TabStop = true;
            this.answer1RadioButton1.Text = "radioButton1";
            this.answer1RadioButton1.UseVisualStyleBackColor = true;
            // 
            // practiceTab
            // 
            this.practiceTab.BackColor = System.Drawing.Color.Thistle;
            this.practiceTab.Controls.Add(this.checkTask3Button);
            this.practiceTab.Controls.Add(this.task3ExplanationBox);
            this.practiceTab.Controls.Add(this.task3Label);
            this.practiceTab.Controls.Add(this.checkTask2Button);
            this.practiceTab.Controls.Add(this.task2CodeBox);
            this.practiceTab.Controls.Add(this.task2Label);
            this.practiceTab.Controls.Add(this.checkPracticeButton);
            this.practiceTab.Controls.Add(this.practiceCodeTextBox);
            this.practiceTab.Controls.Add(this.practiceTaskLabel);
            this.practiceTab.Location = new System.Drawing.Point(4, 25);
            this.practiceTab.Name = "practiceTab";
            this.practiceTab.Size = new System.Drawing.Size(1163, 685);
            this.practiceTab.TabIndex = 2;
            this.practiceTab.Text = "Задания";
            // 
            // checkTask3Button
            // 
            this.checkTask3Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask3Button.Location = new System.Drawing.Point(34, 594);
            this.checkTask3Button.Name = "checkTask3Button";
            this.checkTask3Button.Size = new System.Drawing.Size(110, 41);
            this.checkTask3Button.TabIndex = 10;
            this.checkTask3Button.Text = "Проверить";
            this.checkTask3Button.UseVisualStyleBackColor = false;
            // 
            // task3ExplanationBox
            // 
            this.task3ExplanationBox.Location = new System.Drawing.Point(34, 502);
            this.task3ExplanationBox.Multiline = true;
            this.task3ExplanationBox.Name = "task3ExplanationBox";
            this.task3ExplanationBox.Size = new System.Drawing.Size(517, 86);
            this.task3ExplanationBox.TabIndex = 9;
            // 
            // task3Label
            // 
            this.task3Label.AutoSize = true;
            this.task3Label.Location = new System.Drawing.Point(31, 418);
            this.task3Label.Name = "task3Label";
            this.task3Label.Size = new System.Drawing.Size(44, 16);
            this.task3Label.TabIndex = 8;
            this.task3Label.Text = "label1";
            // 
            // checkTask2Button
            // 
            this.checkTask2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask2Button.Location = new System.Drawing.Point(34, 359);
            this.checkTask2Button.Name = "checkTask2Button";
            this.checkTask2Button.Size = new System.Drawing.Size(110, 41);
            this.checkTask2Button.TabIndex = 6;
            this.checkTask2Button.Text = "Проверить";
            this.checkTask2Button.UseVisualStyleBackColor = false;
            // 
            // task2CodeBox
            // 
            this.task2CodeBox.Location = new System.Drawing.Point(34, 267);
            this.task2CodeBox.Multiline = true;
            this.task2CodeBox.Name = "task2CodeBox";
            this.task2CodeBox.Size = new System.Drawing.Size(517, 86);
            this.task2CodeBox.TabIndex = 5;
            // 
            // task2Label
            // 
            this.task2Label.AutoSize = true;
            this.task2Label.Location = new System.Drawing.Point(31, 201);
            this.task2Label.Name = "task2Label";
            this.task2Label.Size = new System.Drawing.Size(44, 16);
            this.task2Label.TabIndex = 4;
            this.task2Label.Text = "label1";
            // 
            // checkPracticeButton
            // 
            this.checkPracticeButton.BackColor = System.Drawing.Color.LightYellow;
            this.checkPracticeButton.Location = new System.Drawing.Point(34, 139);
            this.checkPracticeButton.Name = "checkPracticeButton";
            this.checkPracticeButton.Size = new System.Drawing.Size(110, 41);
            this.checkPracticeButton.TabIndex = 2;
            this.checkPracticeButton.Text = "Проверить";
            this.checkPracticeButton.UseVisualStyleBackColor = false;
            // 
            // practiceCodeTextBox
            // 
            this.practiceCodeTextBox.Location = new System.Drawing.Point(34, 47);
            this.practiceCodeTextBox.Multiline = true;
            this.practiceCodeTextBox.Name = "practiceCodeTextBox";
            this.practiceCodeTextBox.Size = new System.Drawing.Size(517, 86);
            this.practiceCodeTextBox.TabIndex = 1;
            // 
            // practiceTaskLabel
            // 
            this.practiceTaskLabel.AutoSize = true;
            this.practiceTaskLabel.Location = new System.Drawing.Point(31, 13);
            this.practiceTaskLabel.Name = "practiceTaskLabel";
            this.practiceTaskLabel.Size = new System.Drawing.Size(44, 16);
            this.practiceTaskLabel.TabIndex = 0;
            this.practiceTaskLabel.Text = "label1";
            // 
            // advancedTab
            // 
            this.advancedTab.BackColor = System.Drawing.Color.Thistle;
            this.advancedTab.Controls.Add(this.finishButton);
            this.advancedTab.Controls.Add(this.checkTask2Button1);
            this.advancedTab.Controls.Add(this.advancedCodeTextBox2);
            this.advancedTab.Controls.Add(this.advancedTask2Group);
            this.advancedTab.Controls.Add(this.checkTask1Button);
            this.advancedTab.Controls.Add(this.advancedCodeTextBox1);
            this.advancedTab.Controls.Add(this.advancedTask1Group);
            this.advancedTab.Location = new System.Drawing.Point(4, 25);
            this.advancedTab.Name = "advancedTab";
            this.advancedTab.Size = new System.Drawing.Size(1163, 685);
            this.advancedTab.TabIndex = 3;
            this.advancedTab.Text = "Доп. задание";
            // 
            // finishButton
            // 
            this.finishButton.BackColor = System.Drawing.Color.LightYellow;
            this.finishButton.Location = new System.Drawing.Point(980, 568);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(149, 54);
            this.finishButton.TabIndex = 0;
            this.finishButton.Text = "Завершить";
            this.finishButton.UseVisualStyleBackColor = false;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // checkTask2Button1
            // 
            this.checkTask2Button1.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask2Button1.Location = new System.Drawing.Point(36, 597);
            this.checkTask2Button1.Name = "checkTask2Button1";
            this.checkTask2Button1.Size = new System.Drawing.Size(99, 37);
            this.checkTask2Button1.TabIndex = 8;
            this.checkTask2Button1.Text = "Проверить";
            this.checkTask2Button1.UseVisualStyleBackColor = false;
            // 
            // advancedCodeTextBox2
            // 
            this.advancedCodeTextBox2.Location = new System.Drawing.Point(36, 423);
            this.advancedCodeTextBox2.Multiline = true;
            this.advancedCodeTextBox2.Name = "advancedCodeTextBox2";
            this.advancedCodeTextBox2.Size = new System.Drawing.Size(436, 151);
            this.advancedCodeTextBox2.TabIndex = 7;
            // 
            // advancedTask2Group
            // 
            this.advancedTask2Group.AutoSize = true;
            this.advancedTask2Group.Location = new System.Drawing.Point(33, 345);
            this.advancedTask2Group.Name = "advancedTask2Group";
            this.advancedTask2Group.Size = new System.Drawing.Size(44, 16);
            this.advancedTask2Group.TabIndex = 6;
            this.advancedTask2Group.Text = "label1";
            // 
            // checkTask1Button
            // 
            this.checkTask1Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask1Button.Location = new System.Drawing.Point(36, 284);
            this.checkTask1Button.Name = "checkTask1Button";
            this.checkTask1Button.Size = new System.Drawing.Size(99, 37);
            this.checkTask1Button.TabIndex = 5;
            this.checkTask1Button.Text = "Проверить";
            this.checkTask1Button.UseVisualStyleBackColor = false;
            // 
            // advancedCodeTextBox1
            // 
            this.advancedCodeTextBox1.Location = new System.Drawing.Point(36, 110);
            this.advancedCodeTextBox1.Multiline = true;
            this.advancedCodeTextBox1.Name = "advancedCodeTextBox1";
            this.advancedCodeTextBox1.Size = new System.Drawing.Size(436, 151);
            this.advancedCodeTextBox1.TabIndex = 4;
            // 
            // advancedTask1Group
            // 
            this.advancedTask1Group.AutoSize = true;
            this.advancedTask1Group.Location = new System.Drawing.Point(33, 24);
            this.advancedTask1Group.Name = "advancedTask1Group";
            this.advancedTask1Group.Size = new System.Drawing.Size(44, 16);
            this.advancedTask1Group.TabIndex = 3;
            this.advancedTask1Group.Text = "label1";
            // 
            // PythonLesson1Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1171, 714);
            this.Controls.Add(this.tabControlQuestions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "PythonLesson1Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Урок 1: Переменные и вывод данных в Python";
            this.tabControlQuestions.ResumeLayout(false);
            this.theoryTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.questionsTab.ResumeLayout(false);
            this.question4GroupBox.ResumeLayout(false);
            this.question4GroupBox.PerformLayout();
            this.question3GroupBox.ResumeLayout(false);
            this.question3GroupBox.PerformLayout();
            this.question2GroupBox.ResumeLayout(false);
            this.question2GroupBox.PerformLayout();
            this.question1GroupBox.ResumeLayout(false);
            this.question1GroupBox.PerformLayout();
            this.practiceTab.ResumeLayout(false);
            this.practiceTab.PerformLayout();
            this.advancedTab.ResumeLayout(false);
            this.advancedTab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlQuestions;
        private System.Windows.Forms.TabPage theoryTab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label theoryLabel4;
        private System.Windows.Forms.Label theoryLabel3;
        private System.Windows.Forms.TextBox exampleCodeTextBox3;
        private System.Windows.Forms.Label theoryLabel5;
        private System.Windows.Forms.TextBox exampleCodeTextBox2;
        private System.Windows.Forms.TextBox exampleCodeTextBox;
        private System.Windows.Forms.Label theoryLabel2;
        private System.Windows.Forms.Label theoryLabel1;
        private System.Windows.Forms.TabPage questionsTab;
        private System.Windows.Forms.GroupBox question4GroupBox;
        private System.Windows.Forms.Button checkQuestion4Button;
        private System.Windows.Forms.RadioButton answer4RadioButton4;
        private System.Windows.Forms.RadioButton answer4RadioButton3;
        private System.Windows.Forms.RadioButton answer4RadioButton2;
        private System.Windows.Forms.RadioButton answer4RadioButton1;
        private System.Windows.Forms.GroupBox question3GroupBox;
        private System.Windows.Forms.Button checkQuestion3Button;
        private System.Windows.Forms.RadioButton answer3RadioButton4;
        private System.Windows.Forms.RadioButton answer3RadioButton3;
        private System.Windows.Forms.RadioButton answer3RadioButton2;
        private System.Windows.Forms.RadioButton answer3RadioButton1;
        private System.Windows.Forms.GroupBox question2GroupBox;
        private System.Windows.Forms.Button checkQuestion2Button;
        private System.Windows.Forms.RadioButton answer2RadioButton4;
        private System.Windows.Forms.RadioButton answer2RadioButton3;
        private System.Windows.Forms.RadioButton answer2RadioButton2;
        private System.Windows.Forms.RadioButton answer2RadioButton1;
        private System.Windows.Forms.GroupBox question1GroupBox;
        private System.Windows.Forms.Button checkQuestion1Button;
        private System.Windows.Forms.RadioButton answer1RadioButton4;
        private System.Windows.Forms.RadioButton answer1RadioButton3;
        private System.Windows.Forms.RadioButton answer1RadioButton2;
        private System.Windows.Forms.RadioButton answer1RadioButton1;
        private System.Windows.Forms.TabPage practiceTab;
        private System.Windows.Forms.Button checkTask3Button;
        private System.Windows.Forms.TextBox task3ExplanationBox;
        private System.Windows.Forms.Label task3Label;
        private System.Windows.Forms.Button checkTask2Button;
        private System.Windows.Forms.TextBox task2CodeBox;
        private System.Windows.Forms.Label task2Label;
        private System.Windows.Forms.Button checkPracticeButton;
        private System.Windows.Forms.TextBox practiceCodeTextBox;
        private System.Windows.Forms.Label practiceTaskLabel;
        private System.Windows.Forms.TabPage advancedTab;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.Button checkTask2Button1;
        private System.Windows.Forms.TextBox advancedCodeTextBox2;
        private System.Windows.Forms.Label advancedTask2Group;
        private System.Windows.Forms.Button checkTask1Button;
        private System.Windows.Forms.TextBox advancedCodeTextBox1;
        private System.Windows.Forms.Label advancedTask1Group;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label9;
    }
}