﻿namespace Learning___Program
{
    partial class PascalLesson2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PascalLesson2Form));
            this.tabControlQuestions = new System.Windows.Forms.TabControl();
            this.theoryTab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.theoryLabel4 = new System.Windows.Forms.Label();
            this.exampleCodeTextBox2 = new System.Windows.Forms.TextBox();
            this.exampleCodeTextBox = new System.Windows.Forms.TextBox();
            this.theoryLabel2 = new System.Windows.Forms.Label();
            this.theoryLabel1 = new System.Windows.Forms.Label();
            this.questionsTab = new System.Windows.Forms.TabPage();
            this.question4GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion4Button = new System.Windows.Forms.Button();
            this.answer4RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer4RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question3GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion3Button = new System.Windows.Forms.Button();
            this.answer3RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer3RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question2GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion2Button = new System.Windows.Forms.Button();
            this.answer2RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer2RadioButton1 = new System.Windows.Forms.RadioButton();
            this.question1GroupBox = new System.Windows.Forms.GroupBox();
            this.checkQuestion1Button = new System.Windows.Forms.Button();
            this.answer1RadioButton4 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton3 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton2 = new System.Windows.Forms.RadioButton();
            this.answer1RadioButton1 = new System.Windows.Forms.RadioButton();
            this.practiceTab = new System.Windows.Forms.TabPage();
            this.checkTask2Button = new System.Windows.Forms.Button();
            this.task2CodeBox = new System.Windows.Forms.TextBox();
            this.task2Label = new System.Windows.Forms.Label();
            this.checkPracticeButton = new System.Windows.Forms.Button();
            this.practiceCodeTextBox = new System.Windows.Forms.TextBox();
            this.practiceTaskLabel = new System.Windows.Forms.Label();
            this.advancedTab = new System.Windows.Forms.TabPage();
            this.finishButton = new System.Windows.Forms.Button();
            this.checkAdvancedButton = new System.Windows.Forms.Button();
            this.advancedCodeTextBox = new System.Windows.Forms.TextBox();
            this.advancedTaskLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabControlQuestions.SuspendLayout();
            this.theoryTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.questionsTab.SuspendLayout();
            this.question4GroupBox.SuspendLayout();
            this.question3GroupBox.SuspendLayout();
            this.question2GroupBox.SuspendLayout();
            this.question1GroupBox.SuspendLayout();
            this.practiceTab.SuspendLayout();
            this.advancedTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlQuestions
            // 
            this.tabControlQuestions.Controls.Add(this.theoryTab);
            this.tabControlQuestions.Controls.Add(this.questionsTab);
            this.tabControlQuestions.Controls.Add(this.practiceTab);
            this.tabControlQuestions.Controls.Add(this.advancedTab);
            this.tabControlQuestions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlQuestions.Location = new System.Drawing.Point(0, 0);
            this.tabControlQuestions.Name = "tabControlQuestions";
            this.tabControlQuestions.SelectedIndex = 0;
            this.tabControlQuestions.Size = new System.Drawing.Size(894, 696);
            this.tabControlQuestions.TabIndex = 34;
            // 
            // theoryTab
            // 
            this.theoryTab.Controls.Add(this.panel1);
            this.theoryTab.Location = new System.Drawing.Point(4, 25);
            this.theoryTab.Name = "theoryTab";
            this.theoryTab.Padding = new System.Windows.Forms.Padding(3);
            this.theoryTab.Size = new System.Drawing.Size(886, 667);
            this.theoryTab.TabIndex = 0;
            this.theoryTab.Text = "Теория";
            this.theoryTab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Thistle;
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.theoryLabel4);
            this.panel1.Controls.Add(this.exampleCodeTextBox2);
            this.panel1.Controls.Add(this.exampleCodeTextBox);
            this.panel1.Controls.Add(this.theoryLabel2);
            this.panel1.Controls.Add(this.theoryLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(880, 661);
            this.panel1.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label2.Location = new System.Drawing.Point(28, 377);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(435, 40);
            this.label2.TabIndex = 11;
            this.label2.Text = "Пример программы\r\nПрограмма запрашивает имя и возраст, а затем выводит их:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 420);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(449, 219);
            this.textBox1.TabIndex = 10;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label1.Location = new System.Drawing.Point(28, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 40);
            this.label1.TabIndex = 9;
            this.label1.Text = "3. Вывод переменных\r\nМожно выводить переменные вместе с текстом:";
            // 
            // theoryLabel4
            // 
            this.theoryLabel4.AutoSize = true;
            this.theoryLabel4.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel4.Location = new System.Drawing.Point(28, 208);
            this.theoryLabel4.Name = "theoryLabel4";
            this.theoryLabel4.Size = new System.Drawing.Size(457, 60);
            this.theoryLabel4.TabIndex = 8;
            this.theoryLabel4.Text = "2. Ввод данных\r\nКоманда readln(x) — позволяет пользователю ввести значение \r\nдля " +
    "переменной x.";
            // 
            // exampleCodeTextBox2
            // 
            this.exampleCodeTextBox2.Location = new System.Drawing.Point(29, 331);
            this.exampleCodeTextBox2.Multiline = true;
            this.exampleCodeTextBox2.Name = "exampleCodeTextBox2";
            this.exampleCodeTextBox2.ReadOnly = true;
            this.exampleCodeTextBox2.Size = new System.Drawing.Size(449, 43);
            this.exampleCodeTextBox2.TabIndex = 4;
            this.exampleCodeTextBox2.Text = "writeln(\'Привет, \', name, \'! Твой возраст: \', age);";
            // 
            // exampleCodeTextBox
            // 
            this.exampleCodeTextBox.Location = new System.Drawing.Point(28, 94);
            this.exampleCodeTextBox.Multiline = true;
            this.exampleCodeTextBox.Name = "exampleCodeTextBox";
            this.exampleCodeTextBox.ReadOnly = true;
            this.exampleCodeTextBox.Size = new System.Drawing.Size(449, 100);
            this.exampleCodeTextBox.TabIndex = 2;
            this.exampleCodeTextBox.Text = resources.GetString("exampleCodeTextBox.Text");
            // 
            // theoryLabel2
            // 
            this.theoryLabel2.AutoSize = true;
            this.theoryLabel2.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.theoryLabel2.Location = new System.Drawing.Point(25, 51);
            this.theoryLabel2.Name = "theoryLabel2";
            this.theoryLabel2.Size = new System.Drawing.Size(488, 40);
            this.theoryLabel2.TabIndex = 1;
            this.theoryLabel2.Text = "1. Объявление переменных\r\nПеред использованием переменные нужно объявить в раздел" +
    "е var:\r\n";
            // 
            // theoryLabel1
            // 
            this.theoryLabel1.AutoSize = true;
            this.theoryLabel1.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.theoryLabel1.Location = new System.Drawing.Point(28, 17);
            this.theoryLabel1.Name = "theoryLabel1";
            this.theoryLabel1.Size = new System.Drawing.Size(558, 20);
            this.theoryLabel1.TabIndex = 0;
            this.theoryLabel1.Text = "Переменные — это \"контейнеры\" для хранения данных (чисел, текста и др.).";
            // 
            // questionsTab
            // 
            this.questionsTab.BackColor = System.Drawing.Color.Thistle;
            this.questionsTab.Controls.Add(this.question4GroupBox);
            this.questionsTab.Controls.Add(this.question3GroupBox);
            this.questionsTab.Controls.Add(this.question2GroupBox);
            this.questionsTab.Controls.Add(this.question1GroupBox);
            this.questionsTab.Location = new System.Drawing.Point(4, 25);
            this.questionsTab.Name = "questionsTab";
            this.questionsTab.Padding = new System.Windows.Forms.Padding(3);
            this.questionsTab.Size = new System.Drawing.Size(886, 667);
            this.questionsTab.TabIndex = 1;
            this.questionsTab.Text = "Вопросы";
            // 
            // question4GroupBox
            // 
            this.question4GroupBox.Controls.Add(this.checkQuestion4Button);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton4);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton3);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton2);
            this.question4GroupBox.Controls.Add(this.answer4RadioButton1);
            this.question4GroupBox.Location = new System.Drawing.Point(17, 463);
            this.question4GroupBox.Name = "question4GroupBox";
            this.question4GroupBox.Size = new System.Drawing.Size(870, 161);
            this.question4GroupBox.TabIndex = 7;
            this.question4GroupBox.TabStop = false;
            this.question4GroupBox.Text = "groupBox1";
            // 
            // checkQuestion4Button
            // 
            this.checkQuestion4Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion4Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion4Button.Name = "checkQuestion4Button";
            this.checkQuestion4Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion4Button.TabIndex = 5;
            this.checkQuestion4Button.Text = "Ответить";
            this.checkQuestion4Button.UseVisualStyleBackColor = false;
            // 
            // answer4RadioButton4
            // 
            this.answer4RadioButton4.AutoSize = true;
            this.answer4RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer4RadioButton4.Name = "answer4RadioButton4";
            this.answer4RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton4.TabIndex = 3;
            this.answer4RadioButton4.TabStop = true;
            this.answer4RadioButton4.Text = "radioButton1";
            this.answer4RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton3
            // 
            this.answer4RadioButton3.AutoSize = true;
            this.answer4RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer4RadioButton3.Name = "answer4RadioButton3";
            this.answer4RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton3.TabIndex = 2;
            this.answer4RadioButton3.TabStop = true;
            this.answer4RadioButton3.Text = "radioButton1";
            this.answer4RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton2
            // 
            this.answer4RadioButton2.AutoSize = true;
            this.answer4RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer4RadioButton2.Name = "answer4RadioButton2";
            this.answer4RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton2.TabIndex = 1;
            this.answer4RadioButton2.TabStop = true;
            this.answer4RadioButton2.Text = "radioButton1";
            this.answer4RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer4RadioButton1
            // 
            this.answer4RadioButton1.AutoSize = true;
            this.answer4RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer4RadioButton1.Name = "answer4RadioButton1";
            this.answer4RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer4RadioButton1.TabIndex = 0;
            this.answer4RadioButton1.TabStop = true;
            this.answer4RadioButton1.Text = "radioButton1";
            this.answer4RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question3GroupBox
            // 
            this.question3GroupBox.Controls.Add(this.checkQuestion3Button);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton4);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton3);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton2);
            this.question3GroupBox.Controls.Add(this.answer3RadioButton1);
            this.question3GroupBox.Location = new System.Drawing.Point(17, 296);
            this.question3GroupBox.Name = "question3GroupBox";
            this.question3GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question3GroupBox.TabIndex = 5;
            this.question3GroupBox.TabStop = false;
            this.question3GroupBox.Text = "3";
            // 
            // checkQuestion3Button
            // 
            this.checkQuestion3Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion3Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion3Button.Name = "checkQuestion3Button";
            this.checkQuestion3Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion3Button.TabIndex = 5;
            this.checkQuestion3Button.Text = "Ответить";
            this.checkQuestion3Button.UseVisualStyleBackColor = false;
            // 
            // answer3RadioButton4
            // 
            this.answer3RadioButton4.AutoSize = true;
            this.answer3RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer3RadioButton4.Name = "answer3RadioButton4";
            this.answer3RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton4.TabIndex = 3;
            this.answer3RadioButton4.TabStop = true;
            this.answer3RadioButton4.Text = "radioButton1";
            this.answer3RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton3
            // 
            this.answer3RadioButton3.AutoSize = true;
            this.answer3RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer3RadioButton3.Name = "answer3RadioButton3";
            this.answer3RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton3.TabIndex = 2;
            this.answer3RadioButton3.TabStop = true;
            this.answer3RadioButton3.Text = "radioButton1";
            this.answer3RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton2
            // 
            this.answer3RadioButton2.AutoSize = true;
            this.answer3RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer3RadioButton2.Name = "answer3RadioButton2";
            this.answer3RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton2.TabIndex = 1;
            this.answer3RadioButton2.TabStop = true;
            this.answer3RadioButton2.Text = "radioButton1";
            this.answer3RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer3RadioButton1
            // 
            this.answer3RadioButton1.AutoSize = true;
            this.answer3RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer3RadioButton1.Name = "answer3RadioButton1";
            this.answer3RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer3RadioButton1.TabIndex = 0;
            this.answer3RadioButton1.TabStop = true;
            this.answer3RadioButton1.Text = "radioButton1";
            this.answer3RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question2GroupBox
            // 
            this.question2GroupBox.Controls.Add(this.checkQuestion2Button);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton4);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton3);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton2);
            this.question2GroupBox.Controls.Add(this.answer2RadioButton1);
            this.question2GroupBox.Location = new System.Drawing.Point(17, 151);
            this.question2GroupBox.Name = "question2GroupBox";
            this.question2GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question2GroupBox.TabIndex = 4;
            this.question2GroupBox.TabStop = false;
            this.question2GroupBox.Text = "groupBox1";
            // 
            // checkQuestion2Button
            // 
            this.checkQuestion2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion2Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion2Button.Name = "checkQuestion2Button";
            this.checkQuestion2Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion2Button.TabIndex = 5;
            this.checkQuestion2Button.Text = "Ответить";
            this.checkQuestion2Button.UseVisualStyleBackColor = false;
            // 
            // answer2RadioButton4
            // 
            this.answer2RadioButton4.AutoSize = true;
            this.answer2RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer2RadioButton4.Name = "answer2RadioButton4";
            this.answer2RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton4.TabIndex = 3;
            this.answer2RadioButton4.TabStop = true;
            this.answer2RadioButton4.Text = "radioButton1";
            this.answer2RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton3
            // 
            this.answer2RadioButton3.AutoSize = true;
            this.answer2RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer2RadioButton3.Name = "answer2RadioButton3";
            this.answer2RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton3.TabIndex = 2;
            this.answer2RadioButton3.TabStop = true;
            this.answer2RadioButton3.Text = "radioButton1";
            this.answer2RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton2
            // 
            this.answer2RadioButton2.AutoSize = true;
            this.answer2RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer2RadioButton2.Name = "answer2RadioButton2";
            this.answer2RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton2.TabIndex = 1;
            this.answer2RadioButton2.TabStop = true;
            this.answer2RadioButton2.Text = "radioButton1";
            this.answer2RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer2RadioButton1
            // 
            this.answer2RadioButton1.AutoSize = true;
            this.answer2RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer2RadioButton1.Name = "answer2RadioButton1";
            this.answer2RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer2RadioButton1.TabIndex = 0;
            this.answer2RadioButton1.TabStop = true;
            this.answer2RadioButton1.Text = "radioButton1";
            this.answer2RadioButton1.UseVisualStyleBackColor = true;
            // 
            // question1GroupBox
            // 
            this.question1GroupBox.Controls.Add(this.checkQuestion1Button);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton4);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton3);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton2);
            this.question1GroupBox.Controls.Add(this.answer1RadioButton1);
            this.question1GroupBox.Location = new System.Drawing.Point(17, 6);
            this.question1GroupBox.Name = "question1GroupBox";
            this.question1GroupBox.Size = new System.Drawing.Size(864, 161);
            this.question1GroupBox.TabIndex = 0;
            this.question1GroupBox.TabStop = false;
            this.question1GroupBox.Text = "groupBox1";
            // 
            // checkQuestion1Button
            // 
            this.checkQuestion1Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkQuestion1Button.Location = new System.Drawing.Point(721, 74);
            this.checkQuestion1Button.Name = "checkQuestion1Button";
            this.checkQuestion1Button.Size = new System.Drawing.Size(125, 45);
            this.checkQuestion1Button.TabIndex = 4;
            this.checkQuestion1Button.Text = "Ответить";
            this.checkQuestion1Button.UseVisualStyleBackColor = false;
            // 
            // answer1RadioButton4
            // 
            this.answer1RadioButton4.AutoSize = true;
            this.answer1RadioButton4.Location = new System.Drawing.Point(6, 99);
            this.answer1RadioButton4.Name = "answer1RadioButton4";
            this.answer1RadioButton4.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton4.TabIndex = 3;
            this.answer1RadioButton4.TabStop = true;
            this.answer1RadioButton4.Text = "radioButton1";
            this.answer1RadioButton4.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton3
            // 
            this.answer1RadioButton3.AutoSize = true;
            this.answer1RadioButton3.Location = new System.Drawing.Point(6, 73);
            this.answer1RadioButton3.Name = "answer1RadioButton3";
            this.answer1RadioButton3.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton3.TabIndex = 2;
            this.answer1RadioButton3.TabStop = true;
            this.answer1RadioButton3.Text = "radioButton1";
            this.answer1RadioButton3.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton2
            // 
            this.answer1RadioButton2.AutoSize = true;
            this.answer1RadioButton2.Location = new System.Drawing.Point(6, 47);
            this.answer1RadioButton2.Name = "answer1RadioButton2";
            this.answer1RadioButton2.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton2.TabIndex = 1;
            this.answer1RadioButton2.TabStop = true;
            this.answer1RadioButton2.Text = "radioButton1";
            this.answer1RadioButton2.UseVisualStyleBackColor = true;
            // 
            // answer1RadioButton1
            // 
            this.answer1RadioButton1.AutoSize = true;
            this.answer1RadioButton1.Location = new System.Drawing.Point(6, 21);
            this.answer1RadioButton1.Name = "answer1RadioButton1";
            this.answer1RadioButton1.Size = new System.Drawing.Size(103, 20);
            this.answer1RadioButton1.TabIndex = 0;
            this.answer1RadioButton1.TabStop = true;
            this.answer1RadioButton1.Text = "radioButton1";
            this.answer1RadioButton1.UseVisualStyleBackColor = true;
            // 
            // practiceTab
            // 
            this.practiceTab.BackColor = System.Drawing.Color.Thistle;
            this.practiceTab.Controls.Add(this.checkTask2Button);
            this.practiceTab.Controls.Add(this.task2CodeBox);
            this.practiceTab.Controls.Add(this.task2Label);
            this.practiceTab.Controls.Add(this.checkPracticeButton);
            this.practiceTab.Controls.Add(this.practiceCodeTextBox);
            this.practiceTab.Controls.Add(this.practiceTaskLabel);
            this.practiceTab.Location = new System.Drawing.Point(4, 25);
            this.practiceTab.Name = "practiceTab";
            this.practiceTab.Size = new System.Drawing.Size(886, 667);
            this.practiceTab.TabIndex = 2;
            this.practiceTab.Text = "Задания";
            // 
            // checkTask2Button
            // 
            this.checkTask2Button.BackColor = System.Drawing.Color.LightYellow;
            this.checkTask2Button.Location = new System.Drawing.Point(34, 607);
            this.checkTask2Button.Name = "checkTask2Button";
            this.checkTask2Button.Size = new System.Drawing.Size(110, 41);
            this.checkTask2Button.TabIndex = 6;
            this.checkTask2Button.Text = "Проверить";
            this.checkTask2Button.UseVisualStyleBackColor = false;
            // 
            // task2CodeBox
            // 
            this.task2CodeBox.Location = new System.Drawing.Point(34, 488);
            this.task2CodeBox.Multiline = true;
            this.task2CodeBox.Name = "task2CodeBox";
            this.task2CodeBox.Size = new System.Drawing.Size(517, 113);
            this.task2CodeBox.TabIndex = 5;
            // 
            // task2Label
            // 
            this.task2Label.AutoSize = true;
            this.task2Label.Location = new System.Drawing.Point(31, 352);
            this.task2Label.Name = "task2Label";
            this.task2Label.Size = new System.Drawing.Size(73, 16);
            this.task2Label.TabIndex = 4;
            this.task2Label.Text = "task2Label";
            // 
            // checkPracticeButton
            // 
            this.checkPracticeButton.BackColor = System.Drawing.Color.LightYellow;
            this.checkPracticeButton.Location = new System.Drawing.Point(34, 263);
            this.checkPracticeButton.Name = "checkPracticeButton";
            this.checkPracticeButton.Size = new System.Drawing.Size(110, 41);
            this.checkPracticeButton.TabIndex = 2;
            this.checkPracticeButton.Text = "Проверить";
            this.checkPracticeButton.UseVisualStyleBackColor = false;
            // 
            // practiceCodeTextBox
            // 
            this.practiceCodeTextBox.Location = new System.Drawing.Point(34, 144);
            this.practiceCodeTextBox.Multiline = true;
            this.practiceCodeTextBox.Name = "practiceCodeTextBox";
            this.practiceCodeTextBox.Size = new System.Drawing.Size(517, 113);
            this.practiceCodeTextBox.TabIndex = 1;
            // 
            // practiceTaskLabel
            // 
            this.practiceTaskLabel.AutoSize = true;
            this.practiceTaskLabel.Location = new System.Drawing.Point(31, 13);
            this.practiceTaskLabel.Name = "practiceTaskLabel";
            this.practiceTaskLabel.Size = new System.Drawing.Size(44, 16);
            this.practiceTaskLabel.TabIndex = 0;
            this.practiceTaskLabel.Text = "label1";
            // 
            // advancedTab
            // 
            this.advancedTab.BackColor = System.Drawing.Color.Thistle;
            this.advancedTab.Controls.Add(this.finishButton);
            this.advancedTab.Controls.Add(this.checkAdvancedButton);
            this.advancedTab.Controls.Add(this.advancedCodeTextBox);
            this.advancedTab.Controls.Add(this.advancedTaskLabel);
            this.advancedTab.Location = new System.Drawing.Point(4, 25);
            this.advancedTab.Name = "advancedTab";
            this.advancedTab.Size = new System.Drawing.Size(886, 667);
            this.advancedTab.TabIndex = 3;
            this.advancedTab.Text = "Доп. задание";
            // 
            // finishButton
            // 
            this.finishButton.BackColor = System.Drawing.Color.LightYellow;
            this.finishButton.Location = new System.Drawing.Point(718, 598);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(149, 54);
            this.finishButton.TabIndex = 0;
            this.finishButton.Text = "Завершить";
            this.finishButton.UseVisualStyleBackColor = false;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // checkAdvancedButton
            // 
            this.checkAdvancedButton.BackColor = System.Drawing.Color.LightYellow;
            this.checkAdvancedButton.Location = new System.Drawing.Point(35, 607);
            this.checkAdvancedButton.Name = "checkAdvancedButton";
            this.checkAdvancedButton.Size = new System.Drawing.Size(99, 37);
            this.checkAdvancedButton.TabIndex = 5;
            this.checkAdvancedButton.Text = "Проверить";
            this.checkAdvancedButton.UseVisualStyleBackColor = false;
            // 
            // advancedCodeTextBox
            // 
            this.advancedCodeTextBox.Location = new System.Drawing.Point(35, 248);
            this.advancedCodeTextBox.Multiline = true;
            this.advancedCodeTextBox.Name = "advancedCodeTextBox";
            this.advancedCodeTextBox.Size = new System.Drawing.Size(521, 336);
            this.advancedCodeTextBox.TabIndex = 4;
            // 
            // advancedTaskLabel
            // 
            this.advancedTaskLabel.AutoSize = true;
            this.advancedTaskLabel.Location = new System.Drawing.Point(32, 48);
            this.advancedTaskLabel.Name = "advancedTaskLabel";
            this.advancedTaskLabel.Size = new System.Drawing.Size(44, 16);
            this.advancedTaskLabel.TabIndex = 3;
            this.advancedTaskLabel.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label3.Location = new System.Drawing.Point(531, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(304, 120);
            this.label3.TabIndex = 12;
            this.label3.Text = "3. Основные операции:\r\n- `+` сложение (`sum := a + b`)\r\n- `-` вычитание\r\n- `*` ум" +
    "ножение\r\n- `div` деление нацело (только для integer)\r\n- `mod` остаток от деления" +
    "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.label4.Location = new System.Drawing.Point(531, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Пример:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(535, 248);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(306, 185);
            this.textBox3.TabIndex = 15;
            this.textBox3.Text = resources.GetString("textBox3.Text");
            // 
            // PascalLesson2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(894, 696);
            this.Controls.Add(this.tabControlQuestions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "PascalLesson2Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Урок 2: Переменные и ввод данных";
            this.tabControlQuestions.ResumeLayout(false);
            this.theoryTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.questionsTab.ResumeLayout(false);
            this.question4GroupBox.ResumeLayout(false);
            this.question4GroupBox.PerformLayout();
            this.question3GroupBox.ResumeLayout(false);
            this.question3GroupBox.PerformLayout();
            this.question2GroupBox.ResumeLayout(false);
            this.question2GroupBox.PerformLayout();
            this.question1GroupBox.ResumeLayout(false);
            this.question1GroupBox.PerformLayout();
            this.practiceTab.ResumeLayout(false);
            this.practiceTab.PerformLayout();
            this.advancedTab.ResumeLayout(false);
            this.advancedTab.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlQuestions;
        private System.Windows.Forms.TabPage theoryTab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label theoryLabel4;
        private System.Windows.Forms.TextBox exampleCodeTextBox2;
        private System.Windows.Forms.TextBox exampleCodeTextBox;
        private System.Windows.Forms.Label theoryLabel2;
        private System.Windows.Forms.Label theoryLabel1;
        private System.Windows.Forms.TabPage questionsTab;
        private System.Windows.Forms.GroupBox question4GroupBox;
        private System.Windows.Forms.Button checkQuestion4Button;
        private System.Windows.Forms.RadioButton answer4RadioButton4;
        private System.Windows.Forms.RadioButton answer4RadioButton3;
        private System.Windows.Forms.RadioButton answer4RadioButton2;
        private System.Windows.Forms.RadioButton answer4RadioButton1;
        private System.Windows.Forms.GroupBox question3GroupBox;
        private System.Windows.Forms.Button checkQuestion3Button;
        private System.Windows.Forms.RadioButton answer3RadioButton4;
        private System.Windows.Forms.RadioButton answer3RadioButton3;
        private System.Windows.Forms.RadioButton answer3RadioButton2;
        private System.Windows.Forms.RadioButton answer3RadioButton1;
        private System.Windows.Forms.GroupBox question2GroupBox;
        private System.Windows.Forms.Button checkQuestion2Button;
        private System.Windows.Forms.RadioButton answer2RadioButton4;
        private System.Windows.Forms.RadioButton answer2RadioButton3;
        private System.Windows.Forms.RadioButton answer2RadioButton2;
        private System.Windows.Forms.RadioButton answer2RadioButton1;
        private System.Windows.Forms.GroupBox question1GroupBox;
        private System.Windows.Forms.Button checkQuestion1Button;
        private System.Windows.Forms.RadioButton answer1RadioButton4;
        private System.Windows.Forms.RadioButton answer1RadioButton3;
        private System.Windows.Forms.RadioButton answer1RadioButton2;
        private System.Windows.Forms.RadioButton answer1RadioButton1;
        private System.Windows.Forms.TabPage practiceTab;
        private System.Windows.Forms.Button checkTask2Button;
        private System.Windows.Forms.TextBox task2CodeBox;
        private System.Windows.Forms.Label task2Label;
        private System.Windows.Forms.Button checkPracticeButton;
        private System.Windows.Forms.TextBox practiceCodeTextBox;
        private System.Windows.Forms.Label practiceTaskLabel;
        private System.Windows.Forms.TabPage advancedTab;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.Button checkAdvancedButton;
        private System.Windows.Forms.TextBox advancedCodeTextBox;
        private System.Windows.Forms.Label advancedTaskLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
    }
}